/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author Pawan
 */
public class Assignment3 {

    /**
     * @param args the command line arguments
     */
    static LinkedList<Node> queue = new LinkedList<>();
    static Node root;    
    static int height;
    static int failRequests = 0;
    public static void main(String[] args) {
        
        // TODO code application logic here
        
        Scanner sc = new Scanner(System.in);
        int startindex = 0;
        System.out.println("Enter Highest power of 2");
        height = sc.nextInt();
        int size = (int) Math.pow(2, height);
        
        Data d = new Data();
        d.setStartIndex(startindex);
        d.setSize(size);
        root = new Node(d);
        createTree(root);
        //displayTree(root);
        
        //System.out.println("Enter number of requests?");
        //int requests = sc.nextInt();
        
        //System.out.println("Block Size required?");
        //uncomment for manual testing
        //int inputSize = sc.nextInt();
        //int inputSize = requestMemory(height);
        //int blockReq = blockSize(inputSize);
        //System.out.println(inputSize);

        /*
        int loopCount = 1;
        failRequests = 0;
        while(inputSize != 0){
            
            boolean memoryFound  = allocateMemory(blockReq, root);
            
            if(memoryFound)
                System.out.println("Block Found");
            else{
                System.out.println("Block Unavailable");
                failRequests++;
            }
            //uncomment for manual testing
            //displayTree(root);
            
            System.out.println("Block Size required?");
            //uncomment for manual testing
            //inputSize = sc.nextInt();
            
            //comment for manual testing
            inputSize = requestMemory(height);
            System.out.println(inputSize);
            blockReq = blockSize(inputSize);
            if(loopCount == requests){
                inputSize = 0;
            }
            loopCount++;
        }
        */
        
        allocateMemory(1, root);
        allocateMemory(1, root);
        allocateMemory(1, root);
        allocateMemory(1, root);
        allocateMemory(1, root);
        removeBlock();        
        allocateMemory(4, root);
        
        displayTree(root);
        //System.out.println("Failed Requests: " + failRequests);
        
        //Timer Code
        /*
        Timer requestTimer = new Timer();
        requestTimer.schedule(
                new TimerTask()
                {
                    public void run()
                    {   
                        requestABlock();                        
                    }
                },
            0,1);
        Timer deAllocateTimer = new Timer();
        deAllocateTimer.schedule(
                new TimerTask()
                {
                    public void run()
                    {   
                        removeBlock();
                    }
                },
            0,2);            
        
        Timer t = new Timer();
            t.schedule(
                new TimerTask()
                {
                    public void run()
                    {   
                        requestTimer.cancel();
                        requestTimer.purge();
                        deAllocateTimer.cancel();
                        deAllocateTimer.purge();
                        t.cancel();
                        t.purge();
                        displayTree(root);
                        System.out.println("Fail Requests: " +failRequests);
                    }
                },
            1000);            
            */
    }
        public static void createTree(Node node){
            
            if(node.getData().getSize() == 1){
                return;
            }
            
            int parentsize = node.getData().getSize();
            int childsize =parentsize/2;
            int parentStartIndex = node.getData().getStartIndex();

            Data leftData = new Data(childsize, parentStartIndex);
            Node left = new Node(leftData);
            left.setParent(node);
            node.setLeft(left);
            createTree(left);

            Data rightData = new Data(childsize,parentStartIndex + childsize);
            Node right = new Node(rightData);
            right.setParent(node);
            node.setRight(right);
            createTree(right);            
        }
        
        public static void displayTree(Node node){
            
            if(node.getLeft() != null){
                displayTree(node.getLeft());
            }
            System.out.println(node.getData().getSize() +"- StartPoint: "+ node.getData().getStartIndex()+ " - Allocated :" + node.isAllocated() + " - Full :" + node.isFull());
            if(node.getRight()!= null){
                displayTree(node.getRight());
            }
            return;
            
        }
        
        public static int requestMemory(int size){
            int pow = (int) (Math.random() * (Math.round(size/4)+1));
            int ret = (int)Math.pow(2, pow);
            return ret;
        }
        
        public static boolean allocateMemory(int size, Node node){
            int nodeSize = node.getData().getSize();
            boolean found = false;
            if(node.isFull())
                return false;
            if(nodeSize > size){
                found = allocateMemory(size, node.getLeft());
                if(!found){
                    found = allocateMemory(size, node.getRight());
                }
                if(found){
                    node.setAllocated(found);
                }
            }
            if(node.getData().getSize() == size && !node.isAllocated()){
                node.setFull(true);
                node.setAllocated(true);
                found = true;
                System.out.println("Allocated Node: " + node.getData().getSize() + "- Start Index :" + node.getData().getStartIndex());
                queue.add(node);
            }
            
            if(node.getLeft() != null && node.getLeft().isFull() && node.getRight() != null && node.getRight().isFull()){
                node.setFull(true);
            }
            
            if(!found && node.getParent() == null && size>1){
                boolean found1 = allocateMemory(size/2, node);
                boolean found2 = allocateMemory(size/2, node);
                if(found1 && found2){
                    found = true;
                }
            }
            
            return found;
        }
        
        public static int blockSize(int inp){
            int ret = 0;
            for(int i=0;i<20;i++){
                if(inp <= Math.pow(2, i)){
                    ret = (int) Math.pow(2, i);
                    break;
                }
            }
            return ret;
        }               
        
        public static void removeBlock(){
            if(!queue.isEmpty()){
                Node node = queue.remove();
                deAllocateNode(node);
                System.out.println("Node Deallocated: " + node.getData().getSize() + " - Start Point: " + node.getData().getStartIndex());
            }
        }
        
        public static void deAllocateNode(Node node){
            node.setFull(false);
            node.setAllocated(false);
            if((node.getLeft() != null && node.getLeft().isAllocated()) || (node.getRight()!= null && node.getRight().isAllocated())){
                node.setAllocated(true);
            }
            if(node.getParent() != null){
                deAllocateNode(node.getParent());
            }
        }                
        
        public static void requestABlock(){
            int inputSize = requestMemory(height);
            //System.out.println(inputSize);
            boolean memoryFound  = allocateMemory(blockSize(inputSize), root);
            if(!memoryFound){                           
                System.out.println("Complete Block Unavailable: " + inputSize);
                //failRequests++;
            }
        }
}
